import { Injectable } from '@angular/core';
import { Employee } from './add-employee/Employee';
import {HttpClient, HttpHeaders} from  '@angular/common/http';

const httpOptions ={
  headers : new HttpHeaders({'Content-Type': 'application/json'})
};

@Injectable({
  providedIn: 'root'
})
export class SaveEmployeeService {
  
  _url = 'http://localhost:8083/employee/save';
  //_url='api/save';
  constructor(private http : HttpClient) { }

  save(employee : Employee){
    return this.http.post<any>(this._url, employee);
  }
}
