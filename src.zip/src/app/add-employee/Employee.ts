export class Employee{
    constructor(
        private empId : string,
        private empName : string,
        private empDesignation : string,
        private empSalary : number
    ){}
}